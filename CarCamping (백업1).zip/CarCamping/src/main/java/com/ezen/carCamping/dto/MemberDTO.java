package com.ezen.carCamping.dto;

public class MemberDTO {
	private int mem_num;
	private String mem_id;
	private String mem_email;
	private String mem_password;
	private String mem_userName;
	private String mem_nickName;
	private String mem_phone;
	private String mem_birthday;
	private String mem_gender;
	private RegionDTO regionDTO;
	private int mem_point;
	private int mem_rentalCount;
	private String mem_sysdate;
	private int mem_accept_email;
	private int mem_accept_phone;
	private int mem_accept_privacy;
	private int mem_denied;
	private String mem_image;
	private String mem_summary;
	private String mem_introduce;
	private int mem_reviewCount;
	public int getMem_num() {
		return mem_num;
	}
	public void setMem_num(int mem_num) {
		this.mem_num = mem_num;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getMem_email() {
		return mem_email;
	}
	public void setMem_email(String mem_email) {
		this.mem_email = mem_email;
	}
	public String getMem_password() {
		return mem_password;
	}
	public void setMem_password(String mem_password) {
		this.mem_password = mem_password;
	}
	public String getMem_userName() {
		return mem_userName;
	}
	public void setMem_userName(String mem_userName) {
		this.mem_userName = mem_userName;
	}
	public String getMem_nickName() {
		return mem_nickName;
	}
	public void setMem_nickName(String mem_nickName) {
		this.mem_nickName = mem_nickName;
	}
	public String getMem_phone() {
		return mem_phone;
	}
	public void setMem_phone(String mem_phone) {
		this.mem_phone = mem_phone;
	}
	public String getMem_birthday() {
		return mem_birthday;
	}
	public void setMem_birthday(String mem_birthday) {
		this.mem_birthday = mem_birthday;
	}
	public String getMem_gender() {
		return mem_gender;
	}
	public void setMem_gender(String mem_gender) {
		this.mem_gender = mem_gender;
	}
	public RegionDTO getRegionDTO() {
		return regionDTO;
	}
	public void setRegionDTO(RegionDTO regionDTO) {
		this.regionDTO = regionDTO;
	}
	public int getMem_point() {
		return mem_point;
	}
	public void setMem_point(int mem_point) {
		this.mem_point = mem_point;
	}
	public int getMem_rentalCount() {
		return mem_rentalCount;
	}
	public void setMem_rentalCount(int mem_rentalCount) {
		this.mem_rentalCount = mem_rentalCount;
	}
	public String getMem_sysdate() {
		return mem_sysdate;
	}
	public void setMem_sysdate(String mem_sysdate) {
		this.mem_sysdate = mem_sysdate;
	}
	public int getMem_accept_email() {
		return mem_accept_email;
	}
	public void setMem_accept_email(int mem_accept_email) {
		this.mem_accept_email = mem_accept_email;
	}
	public int getMem_accept_phone() {
		return mem_accept_phone;
	}
	public void setMem_accept_phone(int mem_accept_phone) {
		this.mem_accept_phone = mem_accept_phone;
	}
	public int getMem_accept_privacy() {
		return mem_accept_privacy;
	}
	public void setMem_accept_privacy(int mem_accept_privacy) {
		this.mem_accept_privacy = mem_accept_privacy;
	}
	public int getMem_denied() {
		return mem_denied;
	}
	public void setMem_denied(int mem_denied) {
		this.mem_denied = mem_denied;
	}
	public String getMem_image() {
		return mem_image;
	}
	public void setMem_image(String mem_image) {
		this.mem_image = mem_image;
	}
	public String getMem_summary() {
		return mem_summary;
	}
	public void setMem_summary(String mem_summary) {
		this.mem_summary = mem_summary;
	}
	public String getMem_introduce() {
		return mem_introduce;
	}
	public void setMem_introduce(String mem_introduce) {
		this.mem_introduce = mem_introduce;
	}
	public int getMem_reviewCount() {
		return mem_reviewCount;
	}
	public void setMem_reviewCount(int mem_reviewCount) {
		this.mem_reviewCount = mem_reviewCount;
	}  
	
	
	
	}
	

