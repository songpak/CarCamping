package com.ezen.carCamping.dto;

public class AdminAnnounceDTO {
	private int aa_num;
	private String aa_title;
	private String aa_content;
	private String aa_image1;
	private String aa_image2;
	private String aa_image3;
	private String aa_image4;
	private String aa_image5;
	private String aa_sysdate;
	private String aa_update;
	
	public int getAa_num() {
		return aa_num;
	}
	public void setAa_num(int aa_num) {
		this.aa_num = aa_num;
	}
	public String getAa_title() {
		return aa_title;
	}
	public void setAa_title(String aa_title) {
		this.aa_title = aa_title;
	}
	public String getAa_content() {
		return aa_content;
	}
	public void setAa_content(String aa_content) {
		this.aa_content = aa_content;
	}
	public String getAa_image1() {
		return aa_image1;
	}
	public void setAa_image1(String aa_image1) {
		this.aa_image1 = aa_image1;
	}
	public String getAa_image2() {
		return aa_image2;
	}
	public void setAa_image2(String aa_image2) {
		this.aa_image2 = aa_image2;
	}
	public String getAa_image3() {
		return aa_image3;
	}
	public void setAa_image3(String aa_image3) {
		this.aa_image3 = aa_image3;
	}
	public String getAa_image4() {
		return aa_image4;
	}
	public void setAa_image4(String aa_image4) {
		this.aa_image4 = aa_image4;
	}
	public String getAa_image5() {
		return aa_image5;
	}
	public void setAa_image5(String aa_image5) {
		this.aa_image5 = aa_image5;
	}
	public String getAa_sysdate() {
		return aa_sysdate;
	}
	public void setAa_sysdate(String aa_sysdate) {
		this.aa_sysdate = aa_sysdate;
	}
	public String getAa_update() {
		return aa_update;
	}
	public void setAa_update(String aa_update) {
		this.aa_update = aa_update;
	}
	
}
