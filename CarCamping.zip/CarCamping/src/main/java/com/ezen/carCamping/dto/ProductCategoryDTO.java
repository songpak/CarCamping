package com.ezen.carCamping.dto;

public class ProductCategoryDTO {
	private int pc_num;
	private String pc_name;
	
	public int getPc_num() {
		return pc_num;
	}
	public void setPc_num(int pc_num) {
		this.pc_num = pc_num;
	}
	public String getPc_name() {
		return pc_name;
	}
	public void setPc_name(String pc_name) {
		this.pc_name = pc_name;
	}
	
}
